"""
A tensor is just a n-matrix
"""

from numpy import ndarray as Tensor